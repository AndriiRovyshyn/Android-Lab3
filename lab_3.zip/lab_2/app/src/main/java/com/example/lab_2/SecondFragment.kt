package com.example.lab_2

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment


private const val OUTPUT = "output"

class SecondFragment : Fragment(R.layout.fragment_second) {
    private var output: String? = null
    lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            output = it.getString(OUTPUT)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        textView = view.findViewById(R.id.textView)
        textView.text = output
    }

    companion object {
        fun newInstance(output: String) =
            SecondFragment().apply {
                arguments = Bundle().apply {
                    putString(OUTPUT, output)
            }
        }
    }
}