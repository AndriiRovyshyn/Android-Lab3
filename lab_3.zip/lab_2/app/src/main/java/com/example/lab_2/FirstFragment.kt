package com.example.lab_2

import android.content.Context.MODE_APPEND
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

class FirstFragment : Fragment(R.layout.fragment_first) {
    lateinit var radioGroup: RadioGroup
    lateinit var radioGroup2: RadioGroup
    lateinit var radioButton: RadioButton
    lateinit var radioButton2: RadioButton
    lateinit var radioButton3: RadioButton
    lateinit var radioButton4: RadioButton
    lateinit var radioButton5: RadioButton
    lateinit var button: Button
    lateinit var open: Button
    lateinit var editText: EditText
    val FILE_NAME = "saved.txt"

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        radioGroup = view.findViewById(R.id.radioGroup)
        radioGroup2 = view.findViewById(R.id.radioGroup2)
        radioButton = view.findViewById(R.id.radioButton)
        radioButton2 = view.findViewById(R.id.radioButton2)
        radioButton3 = view.findViewById(R.id.radioButton3)
        radioButton4 = view.findViewById(R.id.radioButton4)
        radioButton5 = view.findViewById(R.id.radioButton5)
        button = view.findViewById(R.id.button)
        open = view.findViewById(R.id.open)
        editText = view.findViewById(R.id.editTextText)
        button.setOnClickListener {
            if (editText.text.isEmpty()) {
                Toast.makeText(activity, "Введіть дані", Toast.LENGTH_SHORT).show()
            } else {
                val result: StringBuilder = StringBuilder()
                result.append("Завдання - " + editText.text + ". ")
                val id = radioGroup.checkedRadioButtonId
                when (id) {
                    radioButton.id -> {
                        result.append("Складність - " + radioButton.text + ". ")
                    }
                    radioButton2.id -> {
                        result.append("Складність - " + radioButton2.text + ". ")
                    }
                    radioButton3.id -> {
                        result.append("Складність - " + radioButton3.text + ". ")
                    }
                }
                val id2 = radioGroup2.checkedRadioButtonId
                when (id2) {
                    radioButton4.id -> {
                        result.append("Тип - " + radioButton4.text + ". ")
                    }
                    radioButton5.id -> {
                        result.append("Тип - " + radioButton5.text + ". ")
                    }
                }
                var fos: FileOutputStream? = null
                try {
                    fos = requireContext().openFileOutput(FILE_NAME, MODE_APPEND)
                    fos!!.write(result.toString().toByteArray())
                    fos.write("\n".toByteArray())
                    Toast.makeText(activity, "Запис збережено", Toast.LENGTH_SHORT).show()
                } catch (ex: IOException) {
                    ex.printStackTrace()
                }
                val fragment = SecondFragment.newInstance(result.toString())
                parentFragmentManager.beginTransaction().apply {
                    replace(R.id.fragment2, fragment)
                    commit()
                }
            }
        }
        open.setOnClickListener {
            var fin: FileInputStream? = null
            try {
                fin = requireContext().openFileInput(FILE_NAME)
                val bytes = ByteArray(fin!!.available())
                fin.read(bytes)
                val intent = Intent(requireContext(), SecondActivity::class.java)
                startActivity(intent)
            } catch (ex: IOException) {
                Toast.makeText(activity, "Сховище пусте", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        fun newInstance() = FirstFragment()
    }
}