package com.example.lab_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val firstFragment = FirstFragment.newInstance()
        val secondFragment = SecondFragment.newInstance("")
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fragment, firstFragment)
            replace(R.id.fragment2, secondFragment)
            commit()
        }
    }
}